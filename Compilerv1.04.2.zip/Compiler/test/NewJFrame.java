import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class NewJFrame extends javax.swing.JFrame {
    
    File file;
    FileWriter writ;
    BufferedWriter write;
    DoubleLinklist a;
    //constructor
    public NewJFrame() {
        initComponents();
    }

    public void makeFile(){
        try{
            this.file=new File("name.txt");
            this.writ = new FileWriter(file);
            this.write=new BufferedWriter(writ);
            this.a=new DoubleLinklist();
        }
        catch(Exception e){
            System.out.println("exception in file writer in cons.");
        }
    }
    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        codeText = new javax.swing.JTextArea();
        convertButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        AssemblyCodeBox = new javax.swing.JTextPane();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        codeText.setColumns(20);
        codeText.setRows(5);
        codeText.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                codeTextKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(codeText);

        convertButton.setText("Convert");
        convertButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                convertButtonMouseClicked(evt);
            }
        });

        jScrollPane2.setViewportView(AssemblyCodeBox);

        jLabel1.setText("Enter C++ Code Here.");

        jLabel2.setText("Equivalent Assembly Code.");

        jLabel3.setText("MAGIC");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(91, 91, 91)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(48, 48, 48))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(convertButton, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(244, 244, 244))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE)
                            .addComponent(jScrollPane2)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(205, 205, 205)
                        .addComponent(jLabel3)))
                .addGap(18, 18, 18)
                .addComponent(convertButton)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void writeToAssemblyBox()throws IOException{
        String line;
        String allData="";
        FileReader writ=new FileReader("name.txt");
        BufferedReader write=new BufferedReader(writ);
        while((line = write.readLine()) != null) {
                allData+=line;
                allData+='\n';
        }  
        AssemblyCodeBox.setText(allData);
    }
    
    public void writeStringToFile (String text) throws IOException{
       write.write(text);
       write.newLine();
    }
    
    public void dataConvert(String line)throws IOException{
        String[] temp;
        String temp2;
        if(line.substring(0, 3).contentEquals("int")){
            temp= line.substring(3,line.length()).split("\\=");
            temp[1]=temp[1].substring(0,temp[1].length()-1);
                                                                        //temp[0]->a
                                                                        //temp[1]->value
            a.insertAtEnd(temp[0], "dword", Integer.parseInt(temp[1]));  //maintaning queue of variables.
            
            temp2=temp[0];
            temp2+=" dword ";
            temp2+=temp[1];
            writeStringToFile(temp2);
            System.out.println(temp[0]);
            System.out.println(temp[1]);
        }
        else if(line.substring(0, 4).contentEquals("char")){
            temp= line.substring(4,line.length()).split("\\="); //a='b';
            temp[1]=temp[1].substring(1,temp[1].length()-2);
            System.out.println(temp[1]);
                                                                        //temp[0]->a
                                                                       //temp[1]->value
            a.insertAtEnd(temp[0], "byte", temp[1]);  //maintaning queue of variables.

            temp2=temp[0];
            temp2+=" byte ";
            temp2+="'"+temp[1]+"'";
            writeStringToFile(temp2);
            System.out.println(temp[0]);
            System.out.println(temp[1]);
        }
        else if(line.substring(0, 4).contentEquals("long")){
            
        }
    }
    
    public void codepart(int temp)
    {
        if(temp ==0 ) // check that all do we need to insert main start or main end
        {
            try{
            writeStringToFile(code);  
            writeStringToFile(mainwrite);      // main start
           }catch(Exception e)
           {
               System.out.println("Exception in codepart function");
           }
        }
        else
        {
            try{
            writeStringToFile(end);      // main end/ return 0 part
           }catch(Exception e)
           {
               System.out.println("Exception in endpart function");
           }
        }    
    }
    
    public String breakingthestatement(String line) // cout variables and string and newline are seperated from the cout
    {
        int count=0;int start=0;
        while(line.substring(start,2) != "<<")
        {
            count++;
            if(line.charAt(count) == ';' || line.charAt(count) == '<')
            {
                break;
            }
        }
        if(line.charAt(count) == '<') count+=0;
        else coutend=false;
        globalcount=count;
        return line.substring(0,count);
    }
    
    public void outputfunc(String line) // converting c++ cout to assembly Call Write
    {
        String temp;coutend=true;globalcount=0;
        while(coutend)
        {
            temp=breakingthestatement(line);// reading statement and converting to assembly
            try
            {
                if(temp.contentEquals("endl"))
                {
                    writeStringToFile("call clrf");
                }
                else
                {
                    writeStringToFile("mov eax,"+temp);
                    writeStringToFile("Call WriteDec");
                }
                line=line.substring(globalcount+2,line.length());
            }catch(Exception e)
            {
                System.out.println("");
            }
            
        }
    }
    
    public String breakingthestatementin(String line) // parts of input statement (just like cout)
    {
        int count=0;int start=0;
        while(line.substring(start,2) != ">>")
        {
            count++;
            if(line.charAt(count) == ';' || line.charAt(count) == '<')
            {
                break;
            }
        }
        return line.substring(0,count);
    }
    
    public void inputfunc(String line)// cin>> working to convert it in assembly
    {
        String temp;
        temp=breakingthestatementin(line);
        try
        {
            writeStringToFile("Call ReadDec");
            writeStringToFile("mov "+temp+",eax");
        }catch(Exception e)
        {
               System.out.println("Error in input function");
        }
    }
    Boolean mainflag=false;Boolean datastart=false;Boolean coutend=true;int globalcount;
    String mainwrite="Main Proc";String code=".code";String end="exit\nmain ENDP\nEND main";boolean concat=false;
    
    public void getCodeLines(String code)throws Exception{
       
        System.out.println("Here");

        for (String line: codeText.getText().split("\\n")){
            if(line.length() <= 8)
            {
                line=line.concat("________");
                concat=true;
            }
            if((line.substring(4,8)).contentEquals("main"))
            {
                mainflag=true;System.out.println("Main part start");
            }
            else if(line.substring(0, 3).contentEquals("int") ||line.substring(0, 4).contentEquals("char") || line.substring(0, 4).contentEquals("long")){
                line=line.replaceAll("________","");
                dataConvert(line);
                datastart=true;
            }
            if(datastart && mainflag && !(line.substring(0, 3).contentEquals("int") || line.substring(0, 4).contentEquals("char") || line.substring(0, 4).contentEquals("long")))
            {
                codepart(0);
                datastart=false;
            }
            if(line.substring(0,6).contentEquals("return"))
            {
                codepart(1);
            }
            if(line.substring(0,6).contentEquals("cout<<"))
            {
                outputfunc(line.substring(6,line.length()));
            }
            if(line.substring(0,5).contentEquals("cin>>"))
            {
                System.out.println(line.substring(0,5));
                inputfunc(line.substring(5,line.length()));
            }
            
            boolean functionFound=false;
            System.out.println("NewJFrame.getCodeLines()");
            for(int i=0; i<line.length(); i++){
                if(line.charAt(i)=='('){
                    System.out.println("NewJFrame.getCodeLines()");
                    for(int j=i; j<line.length(); j++){
                        if(line.charAt(j)==')'){
                            functionFound=true;
                            break;
                        }
                    }
                    if(functionFound){
                 
                        String functionName="";
                        functionName=line.substring(0, i);
                        System.out.println(functionName);
                    }
                    break;
                }
            }
            
        }
    }
    public void includePreCode() throws IOException{
        writeStringToFile("TITLE My First Program (Example.asm)");
        writeStringToFile("INCLUDE Irvine32.inc");
        writeStringToFile(".data");

    }
    public void closeFile()throws IOException{
        write.close();
    }
    private void convertButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_convertButtonMouseClicked
        try{
            makeFile();
            String code=codeText.getText();
            includePreCode();
            getCodeLines(code);
            closeFile();
            writeToAssemblyBox(); 
            closeFile();

        }
        catch(Exception e){
            
        }
    }//GEN-LAST:event_convertButtonMouseClicked

    private void codeTextKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codeTextKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_codeTextKeyPressed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextPane AssemblyCodeBox;
    private javax.swing.JTextArea codeText;
    private javax.swing.JButton convertButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
