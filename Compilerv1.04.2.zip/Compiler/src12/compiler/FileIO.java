package compiler;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class FileIO {
    public void writeInFile(){
        
    }
    public void inludePreCode(File file, String fileName){
        try{
            FileWriter write=new FileWriter(file);
            write.write("TITLE My First Program ("+ fileName +".asm)\n ");
            write.write("\n");
            write.write("INCLUDE Irvine32.inc");
            write.flush();
            write.close();
        }
        catch(Exception e){
            System.out.println("Exception in file writing");
        }
            
    }
    public void creatFile(String fileName){
        try{
            File file=new File(fileName);
            file.createNewFile();
            inludePreCode(file, fileName);
        }
        catch(Exception e){
            System.out.println("Exception in file making");
        }
    }
    public static void main(String [] args){
        FileIO obj=new FileIO();
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter file name");
        String fileName=scan.next();
        obj.creatFile(fileName);
        
            
    }
}
