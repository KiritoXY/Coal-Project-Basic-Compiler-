

import java.util.Scanner;

public class DoubleLinklist <T> {
    public class Node{
        public int noOfParameters;
        public T value;
        public String data;
        public String variableSize;
        public Node next;
        public Node pre;
        Node(){
            data=null;
            next=null;
            pre=null;
            noOfParameters=0;
        }
        Node(String s, int i){ //for functions trace 
            data=s;
            next=null;
            pre=null;
            noOfParameters=i;
        } 
        Node(String d, String VS, T val){ // for data variables
            value=val;
            variableSize=VS;
            data=d;
            next=null;
            pre=null;
            noOfParameters=0;
        }
                                                                                    
    }
    protected Node head;
    protected Node tail;
    protected int size;
    DoubleLinklist(){
        head=null;
        tail=null;
        size=0;
    }
    public void insertAtStart(String data, String variableSize, T val){
        Node newNode=new Node(data, variableSize, val);
        size+=1;
        if(head==null){
            head=newNode;
            newNode=head;
            tail=head;
        }
        else{
           head.pre=newNode;
           newNode.next=head;
           head=newNode;    
           
        }
        
    }
     public void insertAtEnd(String data, String variableSize, T val){
        Node newNode=new Node(data, variableSize,val);
        size+=1;
        if(head==null){
           head=newNode;
           tail=head;
           
        }
        else{
            tail.next=newNode;
            newNode.pre=tail;
            tail=newNode;
           
        }
        
        
    }
     public void insertAtEnd(String data, int noP){
        Node newNode=new Node(data, noP);
        size+=1;
        if(head==null){
           head=newNode;
           tail=head;
           
        }
        else{
            tail.next=newNode;
            newNode.pre=tail;
            tail=newNode;
        }
    }

     public void f(){
        Node temp = null;
        Node current = head;
        while (current != null) {
            Node next = current.next;
            current.next = temp;
            temp = current;
            current = next;
        }
        head = temp;
        current=head;
        for(int i=0; i<size; i++){
            if(i==size-1){
                tail=current;
                tail.next=null;
            }
            current=current.next;
        }
    }
    /* public void insertAtPosition(int position, String data){
        Node current=new Node();
        Node newNode=new Node(data, null, null);
        Node temp=new Node();
        current=head;
        if(head==null){
            insertAtStart(data);
        }
        else if(position==1){
            insertAtStart(data);
            size+=1;
            
        }
        else if(position==size+1){
            insertAtEnd(data);
            size+=1;
        }
        else{
            for(int i=2; i<=size; i++){
                if(i==position){
                    temp=current.next;
                    current.next=newNode;
                    newNode.pre=current;
                    newNode.next=temp;
                    temp.pre=newNode;
                }
                current=current.next;

            }
            
            size+=1;
        }
       
    }
    */
    public void getSize(){
        System.out.println("Size="+size);
    }
    public void getHead(){
        if(head==null){
            System.out.println("Empty list!");
        }
        else{
            System.out.println("Head="+head.data);

        }
    }
    public void getTail(){
        System.out.println("tail="+tail.data);
    }
    public void dis(){
        Node current=new Node();
        current=head;
        for(int i=0; i<size; i++){
            System.out.println(current.data);
            current=current.next;
        }
    }
    
    public void deleteFirst(){
        if(size==1){
            head=null;
            size-=1;
        }
        else if(head==null){
            System.out.println("Empty list!");

        }
        else{
            size-=1;
            head=head.next;
            head.pre=null;
        }
    }
    public void deleteLast(){
        Node current=new Node();
        current=head;
        if(size==1){
            head=null;
            size-=1;
        }
        else if(head==null){
            System.out.println("Empty List!");
        }
        else{
            for(int i=1; i<=size; i++){
                if(i==size-1){
                    current.next=null;
                    size-=1;
                }
                current=current.next;
            }
        }
    }
    public void deleteAtPos(int position){
        Node current=new Node();
        current=head;
        if(head==null){
            System.out.println("Empty List");
        }
        else if(position==1){
            deleteFirst();
            size-=1;
        }
        
        else if(position==size){
            deleteLast();
            size-=1;

        }
        else {
            for(int i=1; i<=size; i++){
                if(i==position-1){
                    Node temp;
                    temp=current.next.next;
                    current.next=temp;
                    temp.pre=current;
                    size-=1;
                //    break;
                }
                current=current.next;
            }
        }
    }
}
